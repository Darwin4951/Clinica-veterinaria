# Huella · Clínica veterinaria

Landing page en español, adaptable a móviles, sin dependencias de compilación. Abre `dist/index.html` o sirve la carpeta `dist` con un servidor estático.

Nombre y servicios ilustrativos. Sustituir por los datos reales antes de usar comercialmente. El formulario prepara un mensaje y permite copiarlo; no envía solicitudes ni confirma citas. No almacena información. No hay testimonios ni credenciales profesionales inventados.

Archivos: `dist/index.html`, `dist/style.css`, `dist/script.js`. Ilustración SVG incluida y creada para esta propuesta. Las fuentes de Google son opcionales y tienen alternativas locales.
